package edu.cs300;

public class MeetingResponse {
	
	public MeetingResponse(int request_id, int avail) {
		this.request_id = request_id;
		this.avail = avail;
	}
	
	int request_id;
	int avail;

}
