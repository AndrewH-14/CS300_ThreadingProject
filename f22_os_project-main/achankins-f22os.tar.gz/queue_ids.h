#define FILE_IN_HOME_DIR "/Users/andrewhankins/Documents/Code/CS300_ThreadingProject/f22_os_project-main/achankins"
//#define FILE_IN_HOME_DIR "/home/achankins/.bashrc"
#define QUEUE_NUMBER 0x14
